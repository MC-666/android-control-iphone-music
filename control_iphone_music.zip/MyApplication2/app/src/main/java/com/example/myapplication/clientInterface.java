package com.example.myapplication;

public interface clientInterface {
    void setMusicName(String name);
    void setAuthor(String name);
    void setDuration(String time);
    void setElapsed(String time);
}
