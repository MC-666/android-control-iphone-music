package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.ref.WeakReference;
import java.util.UUID;


public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private Intent mIntent;
    private BleServerService mBleServerService;
    private BleClientService mBleClientService;
    private Button mBt_play_pause;
    private Button mBt_last_track;
    private Button mBt_next_track;
    private TextView mTxMusicName;
    private TextView mTxMusicAuthor;
    private TextView mTxMusicDuration;
    private TextView mTxMusicElapsed;
    private SeekBar mSbMusic;
    private Button mBt_remote_command;
    //private boolean mbIF;
    // private Intent mIntentBroadcast = new Intent("com.example.communication.RECEIVER");
    // private int mProgress = 0;
    BluetoothGattCharacteristic mCharacteristic = null;
    Intent mIntentStartClient;
    private int mDuration = 0;
    private int mElapsed = 0;
    private long mTimePlaybackInfoWasReceived;
    private boolean mPlaybackState = false;

    public enum RemoteCommandID{
        RemoteCommandIDPlay,
        RemoteCommandIDPause,
        RemoteCommandIDTogglePlayPause,
        RemoteCommandIDNextTrack,
        RemoteCommandIDPreviousTrack,
        RemoteCommandIDVolumeUp,
        RemoteCommandIDVolumeDown,
        RemoteCommandIDAdvanceRepeatMode,
        RemoteCommandIDAdvanceShuffleMode,
        RemoteCommandIDSkipForward,
        RemoteCommandIDSkipBackward,
        RemoteCommandIDLikeTrack,
        RemoteCommandIDDislikeTrack,
        RemoteCommandIDBookmarkTrack,
    }
    //private BluetoothGattService mService = null;

    private static final UUID UUID_AMS_CHARACTERISTIC_REMOTE_COMMAND =
            UUID.fromString("9B3C81D8-57B1-4A8A-B8DF-0E56F7CA51C2");
    private static final UUID UUID_AMS_SERVICE =
            UUID.fromString("89D3502B-0F36-433A-8EF4-C502AD55F8DC");

    private MainThreadHandler mMainHandler;
    private String mMusicName;
    private String mMusicAuthor;
    private String mMusicDuration;
    private String mMusicElapsed;
    private boolean mbPlayOrPause;
    private boolean updateProcessFlag = false;

    private MessageHandler mWorkHandler = null;
    private HandlerThread mWorkThread;
    private static final int MSG_QUERY_PLUGIN_DATABASE = 1;
    private static class MessageHandler extends Handler {
        private WeakReference<MainActivity> mainActivityWeakReference;
        private MessageHandler(Looper looper, MainActivity fragment) {
            super(looper);
            mainActivityWeakReference = new WeakReference<>(fragment);
        }

        @Override
        public void handleMessage(Message msg) {
            try {
                int what = msg.what;
                Log.d(TAG, "handleMessage: what: " + what);
                switch (what) {
                    case MSG_QUERY_PLUGIN_DATABASE:
                        MainActivity activity = null;
                        if (mainActivityWeakReference != null ) {
                            activity = (MainActivity) mainActivityWeakReference.get();
                        }
                        if (activity != null) {
                            activity.updateProcess();
                        }
                        break;
                    default:
                        break;
                }
            } catch (Exception e) {
                Log.d(TAG, "error ");
            }
        }
    }

    private void updateProcess() {
        while(updateProcessFlag) {
            if(mDuration != 0 && mPlaybackState) {

                mMainHandler.sendEmptyMessage(MainThreadHandler.MSG_UPDATE_PROGRESS);



            }
            mBleClientService.sleep(50);
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d(TAG, "------------onCreate");
        initHandler();
        mMainHandler =  new MainThreadHandler(Looper.getMainLooper());
        mIntent = new Intent(getApplicationContext(),BleServerService.class);
        mIntent.setAction(BleServerService.BLE_ACTION_SERVER_SECURE);
        startService(mIntent);
        bindService(mIntent, conn, Context.BIND_AUTO_CREATE);
        //startService(mIntent);
        Log.d(TAG, "------------bindService");
        //getApplicationContext().startService(mIntent);

        mBt_play_pause = (Button)findViewById(R.id.play_or_pause_btn);
        mBt_last_track = (Button)findViewById(R.id.play_last_btn);
        mBt_next_track = (Button)findViewById(R.id.play_next_btn);
        mTxMusicName = (TextView)findViewById(R.id.text_view_name);
        mTxMusicAuthor = (TextView)findViewById(R.id.text_view_artist);
        mTxMusicDuration = (TextView)findViewById(R.id.music_duration);
        mTxMusicElapsed = (TextView)findViewById(R.id.music_elapsed);
        mSbMusic = (SeekBar) findViewById(R.id.seek_bar);
        //mBt_remote_command = (Button)findViewById(R.id.btn_remote_command);
        //mBt_play_pause.setEnabled(false);


        mBt_play_pause.setOnClickListener(new OnClickListener() {
            //设置监听器
            public void onClick(View v) {
                if(mPlaybackState) {
                    mBt_play_pause.setBackgroundResource(R.drawable.bofangb);
                    mPlaybackState = !mPlaybackState;
                } else {
                    mBt_play_pause.setBackgroundResource(R.drawable.bofang);
                    mPlaybackState = !mPlaybackState;
                }


               clickButton(RemoteCommandID.RemoteCommandIDTogglePlayPause);//RemoteCommandIDTogglePlayPause




                //                mIntentBroadcast.putExtra("progress", mProgress);
//                sendBroadcast(mIntentBroadcast);
//                mBleServerService.writeCharacteristic();
//                    //mBleClientService.writeCharacteristic(UUID_AMS_CHARACTERISTIC_REMOTE_COMMAND, "2");
//                        //mService = mBleClientService.mBluetoothGatt.getService(UUID_AMS_SERVICE);
//                        mCharacteristic = mBleClientService.mBluetoothGatt.getService(UUID_AMS_SERVICE).getCharacteristic(UUID_AMS_CHARACTERISTIC_REMOTE_COMMAND);
//                        Log.d(TAG, "-----------mCharacteristic: " + mCharacteristic.getUuid());
//                        mCharacteristic.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
////                        mCharacteristic.setValue(new byte[]{2});
//                    mCharacteristic.setValue(new byte[]{(byte)(RemoteCommandID.RemoteCommandIDTogglePlayPause.ordinal())});
            }
        });
        mBt_last_track.setOnClickListener(new OnClickListener() {
            //设置监听器
            public void onClick(View v) {
                clickButton(RemoteCommandID.RemoteCommandIDPreviousTrack);//RemoteCommandIDPreviousTrack
            }
        });
        mBt_next_track.setOnClickListener(new OnClickListener() {
            //设置监听器
            public void onClick(View v) {
                clickButton(RemoteCommandID.RemoteCommandIDNextTrack);//RemoteCommandIDNextTrack
            }
        });




//        mBt_remote_command.setOnClickListener(new OnClickListener() {
//            //设置监听器
//            public void onClick(View v) {
//                Toast toast = Toast.makeText( MainActivity.this, "Button被点击了", Toast.LENGTH_SHORT);
//                toast.show();
//
//                //mCharacteristic = mBleClientService.mService.getCharacteristic(UUID_AMS_CHARACTERISTIC_REMOTE_COMMAND);
//                if(mCharacteristic != null) {
//                    Toast toast2 = Toast.makeText( MainActivity.this, "mCharacteristic != null", Toast.LENGTH_SHORT);
//                    toast2.show();
//                }
//            }
//        });

    }

    private void initHandler() {
        mWorkThread = new HandlerThread("MiuiWifiSetting");
        mWorkThread.start();
        Looper looper = mWorkThread.getLooper();
        mWorkHandler = new MessageHandler(looper, this);
    }

    private final class MainThreadHandler extends Handler {
        public static final int MSG_UPDATE_MUSIC_NAME = 1;
        public static final int MSG_UPDATE_AUTHOR = 2;
        public static final int MSG_DURATION = 3;
        public static final int MSG_ELAPSED = 4;
        public static final int MSG_UPDATE_PROGRESS = 5;

        public MainThreadHandler(Looper looper) {
            super(looper);
        }

        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case MSG_UPDATE_MUSIC_NAME:
                    if(mMusicName != null) {
                        mTxMusicName.setText(mMusicName);
                    }

                    break;
                case MSG_UPDATE_AUTHOR:
                    if(mMusicAuthor != null) {
                        mTxMusicAuthor.setText(mMusicAuthor);
                    }
                    break;
                case MSG_DURATION:

                    if(mMusicDuration != null) {
                        String[] retval = mMusicDuration.split("\\.");
                        int iDuration = Integer.parseInt(retval[0],10);
                        mDuration = iDuration;
                        int minute = iDuration / 60;
                        int seconds = iDuration % 60;

                        String str=String.format("%02d:%02d", minute,seconds);
                        mTxMusicDuration.setText(str);
                    }
                    break;
                case MSG_ELAPSED:

                    if(mMusicElapsed != null) {
                        String[] retval = mMusicElapsed.split("\\,");
                        String[] elapsedTime;
                        if(Integer.parseInt(retval[0],10) == 1) {
                            mPlaybackState = true;
                            mBt_play_pause.setBackgroundResource(R.drawable.bofangb);
                        } else {
                            mPlaybackState = false;
                            mBt_play_pause.setBackgroundResource(R.drawable.bofang);
                        }

                        if(retval.length >= 3) {
                            elapsedTime = retval[2].split("\\.");
                            int iDuration = Integer.parseInt(elapsedTime[0],10);
                            mElapsed = iDuration;
                            updateProcessFlag = true;
                            mTimePlaybackInfoWasReceived = System.currentTimeMillis() / 1000;
                            int minute = iDuration / 60;
                            int seconds = iDuration % 60;
                            String str = String.format("%02d:%02d", minute,seconds);
                            mTxMusicElapsed.setText(str);
                            if(mDuration != 0) {
                                int location = iDuration*100 / mDuration;
                                mSbMusic.setProgress(location);
                            }
                            if(mWorkHandler != null) {
                                mWorkHandler.sendEmptyMessage(MSG_QUERY_PLUGIN_DATABASE);
                            }
                        }
                    }
                    break;

                case MSG_UPDATE_PROGRESS:
                    int CurrentElapsedTime =
                            (int) (mElapsed+(System.currentTimeMillis() / 1000 - mTimePlaybackInfoWasReceived));
                    int location = CurrentElapsedTime*100 / mDuration;
                    mSbMusic.setProgress(location);

                    int minute = CurrentElapsedTime / 60;
                    int seconds = CurrentElapsedTime % 60;
//                    String str = minute + ":" + seconds;
                    String str=String.format("%02d:%02d", minute,seconds);
                    mTxMusicElapsed.setText(str);
                    break;
                default:
                    break;
            }
        }
    }

    private void clickButton(RemoteCommandID remoteCommand) {
        if(mBleClientService != null && mBleClientService.mService != null) {
            mCharacteristic = mBleClientService.mBluetoothGatt.getService(UUID_AMS_SERVICE).getCharacteristic(UUID_AMS_CHARACTERISTIC_REMOTE_COMMAND);
            mCharacteristic.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
            mCharacteristic.setValue(new byte[]{(byte)(remoteCommand.ordinal())});
            boolean ret = mBleClientService.mBluetoothGatt.writeCharacteristic(mCharacteristic);
        }
    }



    ServiceConnection conn = new ServiceConnection() {
        @Override
        public void onServiceDisconnected(ComponentName name) {

        }

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            Log.d(TAG, "onServiceConnected1");
            //返回一个MsgService对象
            mBleServerService = ((BleServerService.MsgBinder)service).getService();
            //注册回调接口
            mBleServerService.setOnProgressListener(new OnProgressListener() {
                @Override
                public void onProgress() {
                    //mProgressBar.setProgress(progress);
                    //mBt_play_pause.setEnabled(true);
                    mIntentStartClient = new Intent(getApplicationContext(), BleClientService.class);
                    mIntentStartClient.putExtra("Client", mBleServerService.mDevice);
                    startService(mIntentStartClient);
                    bindService(mIntentStartClient, connClient, Context.BIND_AUTO_CREATE);

                }
            });
        }
    };

    final ServiceConnection connClient = new ServiceConnection() {
        @Override
        public void onServiceDisconnected(ComponentName name) {

        }

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {

            Log.d(TAG, "ClientConnect");
            //返回一个MsgService对象
            mBleClientService = ((BleClientService.MsgBinder) service).getService();
            Log.d(TAG, "mBleClientService："+mBleClientService);

            mBleClientService.setClientListener(new clientInterface() {
                @Override
                public void setMusicName(String name) {
                    mMusicName = name;
                    mMainHandler.sendEmptyMessage(MainThreadHandler.MSG_UPDATE_MUSIC_NAME);

                }
                @Override
                public void setAuthor(String name) {
                    mMusicAuthor = name;
                    mMainHandler.sendEmptyMessage(MainThreadHandler.MSG_UPDATE_AUTHOR);
                }
                @Override
                public void setDuration(String time) {
                    mMusicDuration = time;
                    mMainHandler.sendEmptyMessage(MainThreadHandler.MSG_DURATION);
                }
                @Override
                public void setElapsed(String time) {
                    mMusicElapsed = time;
                    mMainHandler.sendEmptyMessage(MainThreadHandler.MSG_ELAPSED);
                }
            });


//            new Handler().postDelayed(new Runnable() {
//                @Override
//                public void run() {
//
//                    mCharacteristic = mBleClientService.mService.getCharacteristic(UUID_AMS_CHARACTERISTIC_REMOTE_COMMAND);
//
//                }
//            },5000); // 延时1秒


            //注册回调接口来接收下载进度的变化
//            mBleServerService.setOnProgressListener(new OnProgressListener() {
//                @Override
//                public void onProgress() {
//                    //mProgressBar.setProgress(progress);
//                    //mBt_play_pause.setEnabled(true);
//                    mIntentStartClient = new Intent(getApplicationContext(), BleClientService.class);
//                    mIntentStartClient.putExtra("Client", mBleServerService.mDevice);
//                    bindService(mIntentStartClient, connClient, Context.BIND_AUTO_CREATE);
//                }
//            });
        }
    };





}