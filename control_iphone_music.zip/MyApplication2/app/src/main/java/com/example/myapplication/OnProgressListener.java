package com.example.myapplication;

public interface OnProgressListener {
    void onProgress();
}
